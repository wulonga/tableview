//
//  YUCustomTestController.h
//  YUFoldingTableViewDemo
//
//  Created by caiyi on 2018/2/6.
//  Copyright © 2018年 timelywind. All rights reserved.
//

#import "YUTestViewController.h"

@interface YUCustomTestController : YUTestViewController

@end
